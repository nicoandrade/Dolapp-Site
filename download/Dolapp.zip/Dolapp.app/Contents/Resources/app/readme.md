# example menubar app

## instructions

- run `npm install`
- run `npm run build` to make Example.app
- run `npm start` to run app from CLI without building Example.app
