const electron = require("electron");
// Module to control application life.
const app = electron.app;

const Menu = electron.Menu;

var menubar = require("menubar");
require("es6-promise").polyfill();
require("isomorphic-fetch");

var mb = menubar({
    height: 200,
    width: 250
});

mb.on("ready", function ready() {
    console.log("app is ready");

    set_price();

    setInterval(function() {
        set_price();
    }, 900000); // 15 min

    function set_price() {
        fetch(
            "https://api-contenidos.lanacion.com.ar/json/v2/economia/cotizacion"
        )
            .then(function(response) {
                if (response.status >= 400) {
                    throw new Error("Bad response from server");
                }
                return response.json();
            })
            .then(function(dolar_response) {
                //console.log(dolar_response);
                var i = 16;
                if (dolar_response[i] == undefined) {
                    i = 15;
                }
                if (dolar_response[i] == undefined) {
                    i = 1;
                }

                var dolar_venta = parseFloat(
                    dolar_response[i].venta.replace(",", ".")
                );
                var dolar_compra = parseFloat(
                    dolar_response[i].compra.replace(",", ".")
                );
                var fecha_string = dolar_response[i].fecha;
                var fecha = new Date(fecha_string + "Z");
                var options = {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                    hour12: false
                };
                console.log(
                    "Compra $" +
                        dolar_compra
                            .toFixed(2)
                            .toString()
                            .replace(".", ",")
                );
                console.log(
                    "Venta $" +
                        dolar_venta
                            .toFixed(2)
                            .toString()
                            .replace(".", ",")
                );
                console.log(fecha.toLocaleDateString("es-ES", options));

                mb.tray.setTitle(
                    dolar_venta
                        .toFixed(2)
                        .toString()
                        .replace(".", ",")
                );

                var icon = "./IconTemplate.png";
                const contextMenu = Menu.buildFromTemplate([
                    {
                        label:
                            "Compra $" +
                            dolar_compra
                                .toFixed(2)
                                .toString()
                                .replace(".", ","),
                        type: "normal"
                    },
                    {
                        label:
                            "Venta     $" +
                            dolar_venta
                                .toFixed(2)
                                .toString()
                                .replace(".", ","),
                        type: "normal"
                    },
                    {
                        type: "separator"
                    },
                    {
                        type: "normal",
                        label: "About",
                        click() {
                            require("electron").shell.openExternal(
                                "https://nicoandrade.github.io/dolapp/"
                            );
                        }
                    },
                    {
                        type: "normal",
                        label: "Cerrar",
                        click: function() {
                            app.quit();
                        }
                    }
                ]);
                mb.tray.setContextMenu(contextMenu);
            });
    }
});
